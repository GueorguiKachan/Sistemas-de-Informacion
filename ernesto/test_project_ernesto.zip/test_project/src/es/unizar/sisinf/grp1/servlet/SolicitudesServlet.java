package es.unizar.sisinf.grp1.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.unizar.sisinf.grp1.db.ConnectionManager;
import es.unizar.sisinf.grp1.model.EquipoFacade;
import es.unizar.sisinf.grp1.model.EquipoVO;
import es.unizar.sisinf.grp1.model.JugadorFacade;
import es.unizar.sisinf.grp1.model.JugadorVO;
import es.unizar.sisinf.grp1.model.UserFacade;
import es.unizar.sisinf.grp1.model.UserVO;
import es.unizar.sisinf.grp1.model.SolicitudJugadorFacade;
import es.unizar.sisinf.grp1.model.SolicitudJugadorVO;
import es.unizar.sisinf.grp1.model.SolicitudVO;
import es.unizar.sisinf.grp1.model.SolicitudEquipoFacade;
import es.unizar.sisinf.grp1.model.SolicitudEquipoVO;
import es.unizar.sisinf.grp1.model.SolicitudFacade;

/**
 * Servlet implementation class BusquedaJugadorSerlvet
 */
@WebServlet(description = "Servlet de creacion de solicitudes", urlPatterns = { "/crearSolicitudJugador", "/crearSolicitudEquipo" ,"/solicitudes",
		"/editarEquipo","/borrarSolicitudEquipo","/borrarSolicitudJugador","/editarJugador", "/GuardarEditarEquipo" })

public class SolicitudesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SolicitudesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		String usuario;
		String campo;
		String valorNuevo;
		int id;
		String id2;
		EquipoVO evo = null;
		JugadorVO jvo = null;
		SolicitudEquipoFacade daoteam = null;
		SolicitudJugadorFacade daoplayer = null;
		SolicitudFacade daosolicitud = null;
		SolicitudVO solicitud = null; 
		SolicitudJugadorVO sjvo = null;
		SolicitudEquipoVO sevo = null;
		List<SolicitudVO> lista = null;
		switch(action) {
			case "/crearSolicitudJugador":
				daoplayer = new SolicitudJugadorFacade();		
				id = Integer.parseInt(request.getParameter("solicitudJugadorNombre"));
				campo = request.getParameter("solicitudJugadorCampo");
				valorNuevo = request.getParameter("solicitudJugadorValorNuevo");
				usuario = (String)request.getSession().getAttribute("user");
				sjvo = new SolicitudJugadorVO(0,campo,valorNuevo,usuario,id);
				daoplayer.introducirSolicitud(sjvo);
				
				request.getRequestDispatcher("PaginaPrincipal.jsp").forward(request, response);
					
			case "/crearSolicitudEquipo":
				daoteam = new SolicitudEquipoFacade();		
				id2 = request.getParameter("solicitudEquipoNombre");
				campo = request.getParameter("solicitudEquipoCampo");
				valorNuevo = request.getParameter("solicitudEquipoValorNuevo");
				usuario = (String)request.getSession().getAttribute("user");
				sevo = new SolicitudEquipoVO(0,campo,valorNuevo,usuario,id2);
				daoteam.introducirSolicitud(sevo);
				
				request.getRequestDispatcher("PaginaPrincipal.jsp").forward(request, response);
			
			case "/solicitudes":
				daosolicitud  = new SolicitudFacade();
				lista = daosolicitud.getTodasSolicitudes();
				request.setAttribute("solicitudes",lista);
				request.getRequestDispatcher("Solicitudes.jsp").forward(request, response);
			case "/editarEquipo":
				sevo = new SolicitudEquipoFacade().getSolicitud(Integer.parseInt(request.getParameter("id")));
				evo = new EquipoFacade().getTeam(sevo.getCodEquipo());
				request.setAttribute("solicitud",sevo);
				request.setAttribute("equipo",evo);
				request.getRequestDispatcher("EditarEquipo.jsp").forward(request, response);
			case "/editarJugador":
				sjvo = new SolicitudJugadorFacade().getSolicitud(Integer.parseInt(request.getParameter("id")));
				jvo = new JugadorFacade().getPlayer(sjvo.getCodJugador());
				request.setAttribute("solicitud",sjvo);
				request.setAttribute("equipo",jvo);
				request.getRequestDispatcher("EditarJugador.jsp").forward(request, response);
			case "/borrarSolicitudEquipo":
				sevo = new SolicitudEquipoFacade().getSolicitud(Integer.parseInt(request.getParameter("id")));
				new SolicitudFacade().eliminarSolicitudEquipo(sevo);
				daosolicitud = new SolicitudFacade();
				lista = daosolicitud.getTodasSolicitudes();
				request.setAttribute("solicitudes",lista);
				request.getRequestDispatcher("Solicitudes.jsp").forward(request, response);
			case "/borrarSolicitudJugador":
				System.out.println("falla1");
				sjvo = new SolicitudJugadorFacade().getSolicitud(Integer.parseInt(request.getParameter("id")));
				System.out.println("falla2");
				new SolicitudFacade().eliminarSolicitudJugador(sjvo);
				System.out.println("falla3");
				daosolicitud = new SolicitudFacade();
				lista = daosolicitud.getTodasSolicitudes();
				request.setAttribute("solicitudes",lista);
				request.getRequestDispatcher("Solicitudes.jsp").forward(request, response);
			case "/GuardarEditarEquipo":
				evo = new EquipoFacade().getTeam(request.getParameter("equipo"));
				solicitud = new SolicitudEquipoFacade().getSolicitud(Integer.parseInt(request.getParameter("idsolicitud")));
				new SolicitudFacade().modificarEquipo(evo ,solicitud);
					
				SolicitudFacade dao6 = new SolicitudFacade();
				List<SolicitudVO> lista5 = dao6.getTodasSolicitudes();
				request.setAttribute("solicitudes",lista5);
				request.getRequestDispatcher("Solicitudes.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
}